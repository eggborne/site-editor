import { getStorage } from 'firebase/storage';

const storage = getStorage();

export {
  storage,
}